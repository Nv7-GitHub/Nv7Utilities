from os import mkdir
from sys import argv, exit
from tkinter.messagebox import showinfo
from tkinter import Tk, BOTH, TOP, TRUE
from tkinter.ttk import Progressbar
from zipfile import ZipFile
from unrar.rarfile import RarFile
from tarfile import open as TarFile
from gzip import open as GZipFile


def extract(path):
    outfolder = path.split(".")[0]
    if path.split(".")[-1] == "zip":
        with ZipFile(path, 'r') as zip_ref:
            zip_ref.extractall(outfolder)
    elif path.split(".")[-1] == "rar":
        with RarFile(path, 'r') as rar_ref:
            mkdir(outfolder)
            rar_ref.extractall(outfolder)
    elif path.split(".")[1:] == ['tar', 'gz']:
        outfolder = '/'.join(outfolder.split('/')[:-1])
        with TarFile(path) as f:
            f.extractall(outfolder)
        exit(0)
    elif path.split(".")[-1] == 'gz':
        outfolder = path.split(".")[0] + "." + path.split(".")[1]
        with GZipFile(path, 'rb') as f_in, open(outfolder, 'wb+') as f_out:
            f_out.write(f_in.read())
    else:
        raise Exception("Unknown File Type")


def main():
    try:
        extract(argv[1])
        exit(0)
    except Exception as e:
        win.iconify()
        showinfo("Error", e)


win = Tk()
win.title("RarOpen")
win.geometry("500x100")
progressbar = Progressbar(win, mode='indeterminate')
progressbar.pack(fill=BOTH, expand=TRUE, side=TOP)
win.after(1, func=main)
win.mainloop()
