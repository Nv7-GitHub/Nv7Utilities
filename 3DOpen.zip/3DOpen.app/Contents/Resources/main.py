# Supported File Types: Collada (*.dae), Alembic (*.abc), Autodesk FBX (*.fbx), Autodesk 3ds (*.3ds), Wavefront (*.obj), Extensible 3D (*.x3d, *.wrl), Stl (*.stl), Stanford (*.ply), Motion Capture (*.bvh), Scalable Vector Graphics (*.svg)
from sys import argv, exit
from tkinter import Tk
from tkinter.filedialog import askopenfilename
from os import system
from os.path import abspath
from tkinter.messagebox import showinfo

win = Tk()
win.title("3DOpen")
win.geometry("1x1")
win.iconify()

if len(argv) == 1:
    filename = askopenfilename(title="Blender Location", filetypes=(("Application", "*.app"), ("All Files", "*.*")))
    if filename != '':
        with open('blendlocation.txt', 'w') as f:
            f.write(filename + "/Contents/MacOS/Blender")

elif len(argv) == 2:
    with open("blendlocation.txt", "r") as f:
        loc = f.read()
        if loc == '':
            filename = askopenfilename(title="Blender Location",
                                       filetypes=(("Application", "*.app"), ("All Files", "*.*")))
            if filename != '':
                with open('blendlocation.txt', 'w') as f2:
                    f2.write(filename + "/Contents/MacOS/Blender")
                    loc = filename + "/Contents/MacOS/Blender"
            else:
                exit(0)

    loc = loc.replace(" ", "\\ ")
    filetype = argv[1].split(".")[-1]
    system(loc + " -P " + abspath("blendfile.py").replace(" ", "\\ ") + " -- --filepath " + argv[1] + " --filetype " + filetype)
    exit(0)
