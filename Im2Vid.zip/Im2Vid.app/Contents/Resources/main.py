from cv2 import imread, VideoWriter, VideoWriter_fourcc
from tkinter import Tk, Label, BOTH, TRUE, Button, TOP, X, OptionMenu, StringVar, CENTER, Frame, DISABLED, NORMAL
from tkinter.ttk import Progressbar
from tkinter.filedialog import askdirectory, asksaveasfilename
from tkinter.messagebox import showinfo
from os import listdir
from sys import exit
from os.path import join


def select_output():
    global filesave
    filesave = asksaveasfilename(title="Choose file to save as",
                                 filetypes=((option.get().upper() + " Files", "*."+option.get()), ("All Files", "*.*")))
    if filesave == '':
        return

    browsebutton.destroy()

    buttonlabel = Label(buttonframe, text=filesave.split("/")[-1], justify=CENTER)
    buttonlabel.pack(fill=BOTH, expand=TRUE)

    menu.config(state=DISABLED)
    writebutton.config(state=NORMAL)


def write():
    win.destroy()

    info = Label(root, text="Reading Images...", justify=CENTER)
    info.pack(side=TOP, fill=X)
    root.update()

    bar = Progressbar(root, mode="determinate")
    bar.pack(fill=BOTH, expand=TRUE)
    root.update()

    files = sorted(listdir(directory))
    bar['maximum'] = len(files)
    imgs = []
    root.update()
    for file in files:
        if file.split('.')[-1] in ['bmp', 'dib', 'jpeg', 'jpg', 'jpe', 'jp2', 'png', 'pbm', 'pgm', 'ppm', 'sr', 'ras',
                                   'tiff', 'tif']:
            imgs.append(imread(join(directory, file)))
            bar['value'] += 1
            root.update()

    info.config(text="Writing Video...")
    bar['value'] = 0
    if option.get() == "mp4":
        filetype = "X264"
    elif option.get() == "avi":
        filetype = "DIVX"
    vid = VideoWriter(filesave, VideoWriter_fourcc(*filetype), 24, (imgs[0].shape[1], imgs[0].shape[0]))
    root.update()
    for img in imgs:
        vid.write(img)
        bar['value'] += 1
        root.update()

    bar['value'] = 0
    bar.config(mode="indeterminate")
    info.config(text="Cleaning Up...")
    root.update()
    vid.release()
    root.destroy()
    exit(0)


root = Tk()
root.title("Im2Vid")
root.geometry("500x200")

win = Frame(root)
win.pack(fill=BOTH, expand=TRUE)

directory = askdirectory(title="Choose Directory of Images")
if directory == '':
    exit(0)

label = Label(win, text="Choose a file format", justify=CENTER)
label.pack(side=TOP, fill=X)

vals = ["mp4", "avi"]
option = StringVar(win)
option.set(vals[0])
menu = OptionMenu(win, option, *vals)
menu.pack(side=TOP)

buttonframe = Frame(win)
buttonframe.pack(side=TOP, fill=X)

browsebutton = Button(buttonframe, text="Select Output File", command=select_output)
browsebutton.pack(fill=BOTH, expand=TRUE)
filesave = None

writebutton = Button(win, text="Write Video", state=DISABLED, command=write)
writebutton.pack(fill=BOTH, expand=TRUE)

win.mainloop()
