"""Fortran to Python Interface Generator.

"""
from __future__ import division, absolute_import, print_function

postpone_import = True
