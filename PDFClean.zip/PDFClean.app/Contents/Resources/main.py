from pdf2image import convert_from_path
from tkinter import Tk, BOTH, Label, Scale, Frame, Button, HORIZONTAL
from tkinter.filedialog import askopenfilename, asksaveasfilename
from sys import exit
from tkinter.ttk import Progressbar
from numpy import array
from cv2 import fastNlMeansDenoisingColored, imwrite
from fpdf import FPDF
from tkinter.messagebox import showinfo


def main():
    try:
        bar = Progressbar(win, length=100, mode="indeterminate")
        label = Label(win, text="Reading PDF File...")
        bar.pack(fill=BOTH, expand=True)
        label.pack()
        win.update()
        images = convert_from_path(file, dpi=quality, poppler_path="/usr/local/Cellar/poppler/0.87.0/bin")

        ims = []
        bar.config(mode="determinate")
        label.config(text="Processing PDF File... ")
        win.update()
        for i, image in enumerate(images):
            open_cv_image = array(image)
            # Convert RGB to BGR
            ims.append(open_cv_image[:, :, ::-1].copy())

            bar['value'] = round(((i+1)/len(images))*100)
            win.update()

        cleaned = []
        label.config(text="Cleaning PDF File...")
        bar['value'] = 0
        win.update()
        for i, image in enumerate(ims):
            cleaned.append(fastNlMeansDenoisingColored(image, None, 10, 10, 7, 21))

            bar['value'] = round(((i+1)/len(images))*100)
            win.update()

        bar['value'] = 0
        label.config(text="Converting Cleaned Data...")
        win.update()
        for i, image in enumerate(cleaned):
            imwrite("images/"+str(i)+".png", image)

            bar['value'] = round(((i+1)/len(images))*100)
            win.update()

        bar['value'] = 0
        label.config(text="Formatting PDF...")
        pdf = FPDF(unit="pt")
        win.update()
        for i, image in enumerate(cleaned):
            pdf.add_page()
            pdf.image("images/"+str(i)+".png", 0, 0, 595.4, 842)

            bar['value'] = round(((i+1)/len(images))*100)
            win.update()

        win.geometry("0x0+"+str(win.winfo_screenwidth())+"+"+str(win.winfo_screenheight()))
        win.update()
        win.iconify()
        bar.destroy()
        label.destroy()
        output = asksaveasfilename(title="Output File Location", filetypes=(("PDF Files", "*.pdf"), ("All Files", "*.*")))
        if not output == "":
            pdf.output(output, "F")

        win.destroy()
        exit(0)
    except Exception as e:
        showinfo("Error", e)


def startup():
    frame = Frame(win)
    frame.pack(fill=BOTH, expand=True)
    scale = Scale(frame, from_=1, to=50, orient=HORIZONTAL)
    scale.set(30)
    scale.pack(fill=BOTH, expand=True)
    button = Button(frame, text="Clean PDF", command=lambda: start(frame, scale))
    button.pack(fill=BOTH, expand=True)
    win.geometry("500x200")


def start(todestroy, scale):
    global quality
    quality = scale.get() * 10
    todestroy.destroy()
    main()


win = Tk()
win.geometry("0x0")
win.title("PDFClean")
quality = None

file = askopenfilename(title="File to PDFClean", filetypes=(("*.pdf", "PDF Files"), ("*.*", "All Files")))
if (file != '') and (file.split('.')[1] == "pdf"):
    win.after(1, startup)
else:
    win.destroy()
    exit(0)

win.mainloop()
